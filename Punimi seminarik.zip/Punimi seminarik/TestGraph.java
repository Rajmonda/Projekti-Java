import java.awt.*;
public class TestGraph
{ public static void main(String[] a)
  { BarGraphWriter e = new BarGraphWriter(200,200);
    e.setTitle("Days in first four months of the year");//ditet ne 4 muajt e pare te vitit
    e.setAxes(20, 120, "30", 90);

    int scale_factor = 3;
    e.setBar1("Jan", 31 * scale_factor, Color.red);
    e.setBar2("Feb", 28 * scale_factor, Color.white);
    e.setBar3("Mar", 31 * scale_factor, Color.blue);
    e.setBar4("Apr", 30 * scale_factor, Color.yellow);
    e.setBar5("",0 * scale_factor,Color.black);
    e.setBar6("",0 * scale_factor,Color.black);
  }
}