import java.awt.*;
public class TestGraph1
{ public static void main(String[] a)
  { BarGraphWriter e = new BarGraphWriter(400,400);
    e.setTitle("Distance from the sun(astronomical unit)");//distanca nga Dielli(njesite astronomike)
    e.setAxes(50, 200, "10", 150);

    int scale_factor = 15;//inicializimi i scale_factor
    e.setBar1("Mer",(int)(0.387 * scale_factor), Color.red);
    e.setBar2("Ven",(int)(0.723 * scale_factor), Color.white);
    e.setBar3("Ear",(int)(1.00  * scale_factor), Color.blue);
    e.setBar4("Mar",(int)(1.524 * scale_factor), Color.yellow);
    e.setBar5("Jup",(int)(5.203 * scale_factor),Color.blue);
    e.setBar6("Sat",(int)(9.539 * scale_factor),Color.red);
  }
}