import java.awt.*;
public class TestGraph2
{ public static void main(String[] a)
  { BarGraphWriter e = new BarGraphWriter(400,400);
    e.setTitle("Mass(relative to Earth)");//masa(ne lidhje me token)
    e.setAxes(50, 200, "10", 150);

    int scale_factor = 15;
    e.setBar1("Mer",(int)( 0.05 * scale_factor), Color.red);
    e.setBar2("Ven",(int)( 0.81 * scale_factor), Color.white);
    e.setBar3("Ear",(int)( 1.00 * scale_factor), Color.blue);
    e.setBar4("Mar",(int)( 0.11 * scale_factor), Color.yellow);
    e.setBar5("Jup",(int)(318.4 * scale_factor),Color.red);
    e.setBar6("Sat",(int)( 95.3 * scale_factor),Color.green);
  }
}