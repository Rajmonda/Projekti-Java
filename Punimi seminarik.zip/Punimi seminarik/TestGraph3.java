import java.awt.*;
public class TestGraph3
{ public static void main(String[] a)
  { BarGraphWriter e = new BarGraphWriter(400,400);
    e.setTitle("Length of day(hours)");//gjatesia e diteve(oreve)
    e.setAxes(50, 200, "10", 150);

    int scale_factor = 1;
    e.setBar1("Mer",(int)(2106.12 * scale_factor),Color.red);
    e.setBar2("Ven",(int)( 718   * scale_factor), Color.white);
    e.setBar3("Ear",(int)(23.93 * scale_factor), Color.blue);
    e.setBar4("Mar",(int)(24.62 * scale_factor), Color.yellow);
    e.setBar5("Jup",(int)(9.83  * scale_factor),Color.green);
    e.setBar6("Sat",(int)(10.03 * scale_factor),Color.blue);
  }
}