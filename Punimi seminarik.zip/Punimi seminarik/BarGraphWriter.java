import java.awt.*;
import javax.swing.*;


class BarGraphWriter extends JPanel
{ private int width;//deklarimi i ndryshoreve
  private int height;
  private int x_pos;
  private int y_pos;
  private int dist1 = 25;
  private int dist2 = 26;
  private Bar initBar = new Bar("",0,Color.black);
  // baret
  Bar bar1 = initBar;//krijimi i objekteve
  Bar bar2 = initBar;
  Bar bar3 = initBar;
  Bar bar4 = initBar;
  Bar bar5 = initBar;
  Bar bar6 = initBar;

  
  JFrame my_frame;//krijimi i kornizes


  public BarGraphWriter(int w, int h )
  { width = w;
    height = h;
    this.setBackground(Color.WHITE);
    my_frame = new JFrame();
    my_frame.getContentPane().add(this);
    my_frame.setSize(width, height);
    my_frame.setVisible(true);
  }

  public void setTitle(String label)
  {
    my_frame.setTitle(label);
  }

    public void planetTitle(String s, int x, int y)
  {
    Graphics g = getGraphics();
    g.drawString(s,x,y);
  }


  public void setAxes(int x_pos, int y_pos, String top_label, int y_height)
  {
    this.y_pos = y_pos; // ben poziten e x te vlefshme edhe per metodat e tjera
    this.x_pos = x_pos; // ben poziten e y te vlefshme edhe per metodat e tjera
    Graphics g = getGraphics();
    g.setColor(Color.BLACK);

    // boshti x
    g.drawLine(x_pos, y_pos, x_pos + 120, y_pos);

    // boshti y
    g.drawLine(x_pos, y_pos, x_pos, (y_pos - y_height));

    // top label
    g.drawString(top_label, 6, (y_pos - y_height));

    // bottom label (0)
    g.drawString("0", 6, y_pos);
  }

  public void setBar1(String label, int height, Color c)
  {
   
    Graphics g = getGraphics();
    g.drawString(label, x_pos, y_pos + 12);
    g.setColor(c);
    g.fillRect(x_pos, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos, y_pos - height,20, height);
    

  }

  public void setBar2(String label, int height, Color c)
  {
   
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2, y_pos + 12);
    g.setColor(c);
    g.fillRect(x_pos + dist1, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1, y_pos - height,20, height);

  }

  public void setBar3(String label, int height, Color c)
  {
   
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2 * 2, y_pos + 12);
    g.setColor(c);
    g.fillRect(x_pos + dist1 * 2, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1 * 2, y_pos - height,20, height);

  }

  public void setBar4(String label, int height, Color c)
  { 
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2 * 3, y_pos + 12);
    g.setColor(c);
    g.fillRect(x_pos + dist1 * 3, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1 * 3, y_pos - height,20, height);
  }

  public void setBar5(String label, int height, Color c)
  { 
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2 * 4, y_pos + 12);
    g.setColor(c);
    g.fillRect(x_pos + dist1 * 4, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1 * 4, y_pos - height,20, height);
  }

  public void setBar6(String label, int height, Color c)
  { 
    Graphics g = getGraphics();
    g.drawString(label, x_pos + dist2 * 5, y_pos + 12);
    g.setColor(c);
    g.fillRect(x_pos + dist1 * 5, y_pos - height,20, height);
    g.setColor(Color.BLACK);
    g.drawRect(x_pos + dist1 * 5, y_pos - height,20, height);
  }

    class Bar{
    private String label = "";//inicializimi i ndryshoreve
    private int h=0;
    private Color color=null;
    public Bar(String label, int h, Color color){
      this.label = label;
      this.h = h;
      this.color = color;
    }
    public String getLabel(){
      return label;
    }
    public double getHeight(){
      return h;
    }
    public Color getColor(){
      return color;
   }
  }
}
